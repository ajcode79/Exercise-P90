﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            byte i;
            int t;
            int arash = 0;
            int[] cost = new int[31];
            for (i = 0; i < 31; i++)
            {
                Console.Write("maghdar hazine kharj shode roz {0} az mah : ", i + 1);
                t = int.Parse(Console.ReadLine());
                if (t > 0)
                    cost[i] = t;
                else
                    cost[i] = 0;

            }
            for (i = 0; i < 31; i++)
                arash = arash + cost[i];
            Console.WriteLine("majmoe hazine mahiane ==> {0}", arash);
            Console.WriteLine("miangin hazine rozane ==> {0} ", ((double)arash / i));
            Console.ReadKey();
        }
    }
}